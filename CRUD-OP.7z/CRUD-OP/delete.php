
<?php
include 'connect.php';


if(isset($_GET['delete'])){
    $id=$_GET['delete'];
    $sql = "DELETE FROM `user_info` where id=$id";
    $result=mysqli_query($con,$sql);
    if($result){
        // echo "Deleted Successfull";
        header('location:display.php');
    }else{
        die(mysqli_error($con));
    }
}



?>